async function analyzeVideo() {
  const fileInput = document.getElementById("videoInput");
  const status = document.getElementById("status");
  const resultBox = document.getElementById("result");

  if (fileInput.files.length === 0) {
    alert("Please select a video");
    return;
  }

  const videoFile = fileInput.files[0];
  const formData = new FormData();
  formData.append("video", videoFile);

  status.innerText = "⏳ Uploading & analyzing... please wait";
  resultBox.style.display = "none";

  try {
    const response = await fetch(
      "https://shotcraft-backend.onrender.com/analyze",
      {
        method: "POST",
        body: formData
      }
    );

    if (!response.ok) {
      throw new Error("Backend error");
    }

    const data = await response.json();

    // Fill results
    document.getElementById("attempts").innerText = data.results.attempts;
    document.getElementById("made").innerText = data.results.shots_made;
    document.getElementById("percentage").innerText =
      data.results.percentage + "%";

    const link = document.getElementById("downloadLink");
    link.href =
      "https://shotcraft-backend.onrender.com" +
      data.output.download_url;

    resultBox.style.display = "block";
    status.innerText = "✅ Analysis completed";

  } catch (error) {
    console.error(error);
    status.innerText = "❌ Something went wrong. Try again.";
  }
}
